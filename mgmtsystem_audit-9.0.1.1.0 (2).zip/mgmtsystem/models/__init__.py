# -*- coding: utf-8 -*-

from . import mgmtsystem_system, res_config
