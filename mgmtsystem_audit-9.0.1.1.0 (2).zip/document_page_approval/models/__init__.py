# -*- coding: utf-8 -*-
from . import document_page_approval, document_page_history_workflow
