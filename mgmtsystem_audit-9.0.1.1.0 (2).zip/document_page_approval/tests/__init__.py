# -*- coding: utf-8 -*-
from . import test_document_page_approval, test_document_page_history_workflow
